let box=document.querySelectorAll(".b");
let res=document.querySelector(".reset");
let news=document.querySelector("#new");
let container=document.querySelector(".con");
let sms=document.querySelector("#msg");
let turno=true;
const win=[
    [0,1,2],
    [0,3,6],
    [0,4,8],
    [1,4,7],
    [2,5,8],
    [3,4,5],
    [6,7,8],
    [2,4,6]
];
const re=()=>
{ turno=true;
  ena();
  container.classList.add("hide");

}

box.forEach((b)=>{
      b.addEventListener("click", ()=>{
        console.log("box was cliked");
        if(turno){
            b.innerText="O";
            b.classList.add("o");//player 0
            turno=false;
        
        }
        else{
            b.innerText="X";//player x
            b.classList.add("x");
            turno=true;
        }
        b.disabled=true;
        check();
});
});
const disa=()=>{
    for(let bo of box){
        bo.disabled=true;
    }
}
const ena=()=>{
     for(let bo of box){
        bo.disabled=false;
        bo.innerText="";
    }
}

const showwin=(winner)=>{
    sms.innerText=`congratulations ,Winner is ${winner}`;
    container.classList.remove("hide");
    disa();
}
const check=()=>{
    for(let pattern of win){
        let pos1=box[pattern[0]].innerText;
        let pos2=box[pattern[1]].innerText;
        let pos3=box[pattern[2]].innerText;
        if(pos1!=""&& pos2!=""&& pos3!="" ){
            if(pos1===pos2 && pos2===pos3){
                console.log("winner ",pos1);
                showwin(pos1);
            }
        }
    }
};
news.addEventListener("click",re);
res.addEventListener("click",re);

    